using System;

namespace skmDataStructures
{
	namespace BST 
	{
		/// <summary>
		/// Summary description for TraversalMethods.
		/// </summary>
		public enum TraversalMethods
		{
			Preorder,
			Inorder,
			Postorder		
		}
	}
}